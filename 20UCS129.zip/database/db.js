const mongoose = require('mongoose');


const connectToThUer = async () => {
    try {
        await mongoose.connect("mongodb://localhost:27017/userData");
    } catch (e) {
        console.log(e);
    }

};

module.exports = connectToThUer;


