const express = require("express");
const router = express.Router();
const chekTheUserData = require("../Middleware/datachekignWithPost");
const userModel = require("../models/userData");


router.post("/main", chekTheUserData, async (req, res) => {
    try {
        if (!req.body) {
            res.status(400).send({ result: false, message: "Provide the user data" });
        }
        const { username, password, age } = req.body;
        await userModel.create({ username, password, age });
        res.status(200).send("User is created");

    } catch (e) {
        console.log(e);
        res.status(500).send("Back end error");
    }


})

module.exports = router;