const express = require("express");
const app = express();
const port = process.env.PORT || 9000;
const router = require("./Router/mainRouter");
const connectToThUer = require("./database/db");


const midFun = require("./Middleware/chekingTheData");
app.use(express.json());
app.use(async (req, res, next) => {
    try {
        console.log("This is global middleware");
        next();
    } catch (e) {
        console.log(e);
    }
})
app.use(router);



app.get("/", midFun, async (req, res) => {
    try {
        res.status(200).send("Up and working");
    } catch (e) {
        console.log(e);
        res.status(500).send({ result: false, message: "Backend error" });

    }
})

connectToThUer().then(app.listen(port, () => {
    console.log(`Server is started on the port ${port}`);
}));



