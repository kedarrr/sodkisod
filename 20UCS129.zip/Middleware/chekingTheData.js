

const midFun = async (req, res, next) => {
    try {
        console.log("This is middleware");
        next();
    } catch (e) {
        console.log(e);
    }
}

module.exports = midFun;