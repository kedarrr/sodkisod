

const chekTheUserData = async (req, res, next) => {
    try {
        if (req.body) {
            console.log("The user data is cheked in middleware :", req.body);
        }
        next();
    } catch (e) {
        console.log(e);
    }
}

module.exports = chekTheUserData;